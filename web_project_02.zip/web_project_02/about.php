<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" type="text/css" href="css/style.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500&family=Redressed&display=swap" rel="stylesheet">
  
</head>
<body>
  <?php include 'menu.php'; ?>

<div class="jumbotron">
  <h1>MOMO INN </h1>
  <p>Five star hotel in Bogura</p>
</div>

<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">About us</h2>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img/momoinn2.jpg" class="img-fluid aboutimg">
      </div>

      <div class="col-lg-6 col-md-6 col-12">
        <h2 class="display-4">Hotel MOMO INN</h2>
        <p class="py-4">Welcome to Momo Inn. Imagine a charming and picturesque Heritage village in the north part of the countryside, surrounded by the spectacular natural beauty
        </p>
        <a href="about.php" class="btn btn-outline-success">Learn More</a>
      </div>
    </div>  
  </div>
</section>

<footer>
  <p class="p-3 bg-dark text-white text-center">@hotelmomoinn</p>
</footer>

</body>
</html>
