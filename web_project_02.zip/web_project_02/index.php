<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  

  	<link rel="stylesheet" type="text/css" href="css/style.css">
  	
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500&family=Redressed&display=swap" rel="stylesheet">
</head>
<body>

	<?php include 'menu.php'; ?>

<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
    <li data-target="#demo" data-slide-to="3"></li>
    <li data-target="#demo" data-slide-to="4"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/momoinn2.jpg" alt="Momo Inn" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Momo Inn</h3>
        <p>Full view</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="img/momoinn4.jpg" alt="Sweeming Pool" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Sweeming Pool</h3>
        
      </div>   
    </div>

    <div class="carousel-item">
      <img src="img/mahasthangarh2.jpg" alt="Mahasthangarh" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Mahasthangarh</h3>
        
      </div>   
    </div>

    <div class="carousel-item">
      <img src="img/momoin8.jpg" alt=" momoin8 " width="1100" height="500">
      <div class="carousel-caption">
        <h3>Momo inn</h3>
        
      </div>   
    </div>
    <div class="carousel-item">
      <img src="img/movie-theater.jpg" alt="movie-theater" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Movie Theater</h3>
        
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>


<footer>
  <p class="p-3 bg-dark text-white text-center">@hotelmomoinn</p>
</footer>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>











