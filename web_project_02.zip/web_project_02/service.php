<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" type="text/css" href="css/style.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500&family=Redressed&display=swap" rel="stylesheet">
  
</head>
<body>
  <?php include 'menu.php'; ?>

<div class="jumbotron">
  <h1>MOMO INN </h1>
  <p>Five star hotel in Bogura</p>
</div>



<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">Our Services</h2>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:400px">
          <img class="card-img-top" src="img/helipad2.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Helipad</h4>
            <p class="card-text">Some example text.</p>
            <a href="#" class="btn btn-primary">See more</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:400px">
          <img class="card-img-top" src="img/momoinn6.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Sweeming pool</h4>
            <p class="card-text">Some example text.</p>
            <a href="#" class="btn btn-primary">See more</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:400px">
          <img class="card-img-top" src="img/gym2.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">GYM</h4>
            <p class="card-text">Some example text.</p>
            <a href="#" class="btn btn-primary">See more</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:400px">
          <img class="card-img-top" src="img/game.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Game zone</h4>
            <p class="card-text">Some example text.</p>
            <a href="#" class="btn btn-primary">See more</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:400px">
          <img class="card-img-top" src="img/giftshop.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Gift Shop</h4>
            <p class="card-text">Some example text.</p>
            <a href="#" class="btn btn-primary">See more</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12">
        <div class="card" style="width:400px">
          <img class="card-img-top" src="img/movie-theater.jpg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Movie Theater </h4>
            <p class="card-text">Some example text.</p>
            <a href="#" class="btn btn-primary">See more</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>






<footer>
  <p class="p-3 bg-dark text-white text-center">@hotelmomoinn</p>
</footer>


</body>
</html>