<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" type="text/css" href="css/style.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500&family=Redressed&display=swap" rel="stylesheet">
  
</head>
<body>
  <?php include 'menu.php'; ?>

<div class="jumbotron">
  <h1>MOMO INN </h1>
  <p>Five star hotel in Bogura</p>
</div>



<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">Our gallery</h2>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn1.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn2.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn3.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn4.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn5.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn6.jpg" class="img-fluid pb-">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/momoinn7.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/helipad1.jpg" class="img-fluid pb-5">
      </div>

      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/game.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/gym2.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/lake.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/n.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/banquet.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/bogramap.jpg" class="img-fluid pb-5">
      </div>
      <div class="col-lg-4 colmd-4 col-12">
        <img src="img/movie-theater.jpg" class="img-fluid pb-5">
      </div>
    </div>
  </div>
</section>





<footer>
  <p class="p-3 bg-dark text-white text-center">@hotelmomoinn</p>
</footer>
</body>
</html>